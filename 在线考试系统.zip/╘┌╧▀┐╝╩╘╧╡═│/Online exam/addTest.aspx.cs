﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;
public partial class addTest : System.Web.UI.Page
{
    CommonClass ccObj = new CommonClass();
    UserClass ucObj = new UserClass();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void addLinkButton_Click(object sender, EventArgs e)
    {
        int IntReturnValue = ucObj.AddTest(DropDownList1.SelectedItem.Text.Trim(), contentTextBox.Text.Trim(), ATextBox.Text.Trim(), BTextBox.Text.Trim(), CTextBox.Text.Trim(), DTextBox.Text.Trim(), answerTextBox.Text.Trim(), analyTextBox.Text.Trim(), DropDownList2.SelectedItem.Text.Trim(), tcidTextBox.Text.Trim());

        if (IntReturnValue == 1)
        {
            Response.Write(ccObj.MessageBoxPage("添加成功！"));
        }
        else
        {
            Response.Write(ccObj.MessageBoxPage("添加失败！"));

        }
    }
    public void ReadExcel(string sExcelFile, GridView dgBom)
    {
        DataTable ExcelTable;
        DataSet ds = new DataSet();
        //Excel的连接
        //OleDbConnection objConn = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + sExcelFile + ";" + "Extended Properties=Excel 8.0;");
        OleDbConnection objConn = new OleDbConnection("Provider=Microsoft.Ace.OleDb.12.0;Data Source=" + sExcelFile + ";" + "Extended Properties='Excel 12.0; HDR=Yes; IMEX=1'");
        try
        {
            objConn.Open();
            DataTable schemaTable = objConn.GetOleDbSchemaTable(System.Data.OleDb.OleDbSchemaGuid.Tables, null);
            string tableName = schemaTable.Rows[0][2].ToString().Trim();//获取 Excel 的表名，默认值是sheet1
            string strSql = "select * from [" + tableName + "]";
            OleDbCommand objCmd = new OleDbCommand(strSql, objConn);
            OleDbDataAdapter myData = new OleDbDataAdapter(strSql, objConn);
            myData.Fill(ds, tableName);//填充数据
            dgBom.DataSource = ds;
            dgBom.DataBind();
            objConn.Close();
            ExcelTable = ds.Tables[tableName];
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message, ex);
        }
        finally
        {
            if (objConn.State == ConnectionState.Open)
            {
                objConn.Close();
            }
        }

        int iColums = ExcelTable.Columns.Count;//列数
        int iRows = ExcelTable.Rows.Count;//行数
        //定义二维数组存储 Excel 表中读取的数据
        string[,] storedata = new string[iRows, iColums];
        for (int i = 0; i < ExcelTable.Rows.Count; i++)
            for (int j = 0; j < ExcelTable.Columns.Count; j++)
            {
                //将Excel表中的数据存储到数组
                storedata[i, j] = ExcelTable.Rows[i][j].ToString();
            }
        int excelBom = 0;//记录表中有用信息的行数，有用信息是指除去表的标题和表的栏目，本例中表的用用信息是从第三行开始
        //确定有用的行数
        for (int k = 2; k < ExcelTable.Rows.Count; k++)
            if (storedata[k, 1] != "")
                excelBom++;
        if (excelBom == 0)
        {
            Response.Write("<script language=javascript>alert('您导入的表格不合格式！')</script>");
        }
        else
        {
            //Response.Write("<script language=javascript>alert('导入的表格合格式！')</script>");
            //LoadDataToDataBase(storedata，excelBom)//该函数主要负责将 storedata 中有用的数据写入到数据库中，在此不是问题的关键省略 
        }
    }
    protected void btninsert_Click(object sender, EventArgs e)
    {

    }
    protected void btn2_Click1(object sender, EventArgs e)
    {
        string filepath = FileUpload1.PostedFile.FileName;
        ReadExcel(filepath, dgBom);
    }
    protected void btninsert_Click1(object sender, EventArgs e)
    {
        foreach (GridViewRow gv in dgBom.Rows)
        {
            string con = System.Configuration.ConfigurationManager.ConnectionStrings["administratorConnectionString"].ToString();
            SqlConnection conn = new SqlConnection(con);
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into testBase (Tb_type,Tb_content,Tb_A,Tb_B,Tb_C,Tb_D,Tb_answer,Tb_analy,Tb_grade,Tc_id) values(@Tb_type,@Tb_content,@Tb_A,@Tb_B,@Tb_C,@Tb_D,@Tb_answer,@Tb_analy,@Tb_grade,@Tc_id)";
            cmd.Parameters.Add("@Tb_type", SqlDbType.VarChar, 10);
            cmd.Parameters.Add("@Tb_content", SqlDbType.VarChar, 500);
            cmd.Parameters.Add("@Tb_A", SqlDbType.VarChar, 50);
            cmd.Parameters.Add("@Tb_B", SqlDbType.VarChar, 50);
            cmd.Parameters.Add("@Tb_C", SqlDbType.VarChar, 50);
            cmd.Parameters.Add("@Tb_D", SqlDbType.VarChar, 50);
            cmd.Parameters.Add("@Tb_answer", SqlDbType.VarChar, 8);
            cmd.Parameters.Add("@Tb_analy", SqlDbType.VarChar, 500);
            cmd.Parameters.Add("@Tb_grade", SqlDbType.Char, 2);
            cmd.Parameters.Add("@Tc_id", SqlDbType.Int);
            cmd.Parameters["@Tb_type"].Value = ((TextBox)gv.FindControl("Tb_type")).Text;
            cmd.Parameters["@Tb_content"].Value = ((TextBox)gv.FindControl("Tb_content")).Text;
            cmd.Parameters["@Tb_A"].Value = ((TextBox)gv.FindControl("Tb_A")).Text;
            cmd.Parameters["@Tb_B"].Value = ((TextBox)gv.FindControl("Tb_B")).Text;
            cmd.Parameters["@Tb_C"].Value = ((TextBox)gv.FindControl("Tb_C")).Text;
            cmd.Parameters["@Tb_D"].Value = ((TextBox)gv.FindControl("Tb_D")).Text;
            cmd.Parameters["@Tb_answer"].Value = ((TextBox)gv.FindControl("Tb_answer")).Text;
            cmd.Parameters["@Tb_analy"].Value = ((TextBox)gv.FindControl("Tb_analy")).Text;
            cmd.Parameters["@Tb_grade"].Value = ((TextBox)gv.FindControl("Tb_grade")).Text;
            cmd.Parameters["@Tc_id"].Value = Convert.ToInt32(((TextBox)gv.FindControl("Tc_id")).Text.Trim().ToString());

            try
            {
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }
            finally
            {
                if (conn != null)
                    conn.Dispose();
            }
        }
    }
}