﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

/// <summary>
/// UserClass 的摘要说明
/// </summary>
public class UserClass
{
    DBClass dbObj = new DBClass();
	public UserClass()
	{
		//
		// TODO: 在此处添加构造函数逻辑
		//
	}
    //***************************************登录界面************************************************************
    /// <summary>
    /// 三个用户登录方法
    /// </summary>
    /// <param name="strName">用户名</param>
    /// <param name="strPwd">用户密码</param>
    /// <returns>返回数据源中的数据表</returns>
    public DataTable ManagerLogin(string strName, string strPwd)
    {
        SqlCommand myCmd = dbObj.GetCommandStr("select * from Manager where Ad_name=@UserName and Ad_password=@Password;");
        //添加参数(用户名)
        SqlParameter Name = new SqlParameter("@UserName", SqlDbType.VarChar, 50);
        Name.Value = strName;
        myCmd.Parameters.Add(Name);
        //添加参数(密码)
        SqlParameter Pwd = new SqlParameter("@Password", SqlDbType.VarChar, 50);
        Pwd.Value = strPwd;
        myCmd.Parameters.Add(Pwd);
        dbObj.ExecNonQuery(myCmd);
        DataTable dsTable = dbObj.GetDataSet(myCmd, "Manager");
        return dsTable;
    }
    public DataTable TeacherLogin(string strName, string strPwd)
    {
        SqlCommand myCmd = dbObj.GetCommandStr("select * from Teacher where Tc_name=@UserName and Tc_password=@Password;");
        //添加参数(用户名)
        SqlParameter Name = new SqlParameter("@UserName", SqlDbType.VarChar, 50);
        Name.Value = strName;
        myCmd.Parameters.Add(Name);
        //添加参数(密码)
        SqlParameter Pwd = new SqlParameter("@Password", SqlDbType.VarChar, 50);
        Pwd.Value = strPwd;
        myCmd.Parameters.Add(Pwd);
        dbObj.ExecNonQuery(myCmd);
        DataTable dsTable = dbObj.GetDataSet(myCmd, "Teacher");
        return dsTable;
    }
    public DataTable StudentLogin(string strName, string strPwd)
    {
        SqlCommand myCmd = dbObj.GetCommandStr("select * from Student where St_name=@UserName and St_pwd=@Password;");
        //添加参数(用户名)
        SqlParameter Name = new SqlParameter("@UserName", SqlDbType.VarChar, 50);
        Name.Value = strName;
        myCmd.Parameters.Add(Name);
        //添加参数(密码)
        SqlParameter Pwd = new SqlParameter("@Password", SqlDbType.VarChar, 50);
        Pwd.Value = strPwd;
        myCmd.Parameters.Add(Pwd);
        dbObj.ExecNonQuery(myCmd);
        DataTable dsTable = dbObj.GetDataSet(myCmd, "Student");
        return dsTable;
    }
    //***************************************注册界面************************************************************
    /// <summary>
    /// 向用户表中插入信息
    /// </summary>
    /// <param name="strName">会员名</param>
    /// <param name="strPassword">密码</param>
    /// <param name="strRealName">真实姓名</param>
    /// <param name="blSex">性别</param>
    /// <param name="strPhonecode">电话号码</param>
    /// <param name="strEmail">E_Mail</param>
    /// <param name="strAddress">会员详细地址</param>
    /// <param name="strPostCode">邮编</param>
    /// <returns>返回用户ID代号</returns>
    public int AddUser(string strName, string strPassword,bool blSex, string strquestion, string stranswer, string strcardNo, string strphone,string stremail)
    {
        SqlCommand myCmd = dbObj.GetCommandProc("proc_adduser");    
        //添加参数
        SqlParameter name = new SqlParameter("@Name", SqlDbType.VarChar, 20);
        name.Value = strName;
        myCmd.Parameters.Add(name);
        //添加参数
        SqlParameter password = new SqlParameter("@Password", SqlDbType.VarChar, 20);
        password.Value = strPassword;
        myCmd.Parameters.Add(password);
        //添加参数
        SqlParameter sex = new SqlParameter("@Sex", SqlDbType.Bit, 1);
        sex.Value = blSex;
        myCmd.Parameters.Add(sex);
        //添加参数
        SqlParameter question = new SqlParameter("@question", SqlDbType.VarChar, 50);
        question.Value = strquestion;
        myCmd.Parameters.Add(question);
        //添加参数
        SqlParameter answer = new SqlParameter("@answer", SqlDbType.VarChar, 50);
        answer.Value = stranswer;
        myCmd.Parameters.Add(answer);
        //添加参数
        SqlParameter cardNo = new SqlParameter("@cardNo", SqlDbType.VarChar, 18);
        cardNo.Value = strcardNo;
        myCmd.Parameters.Add(cardNo);
        //添加参数
        SqlParameter phone = new SqlParameter("@phone", SqlDbType.VarChar, 11);
        phone.Value = strphone;
        myCmd.Parameters.Add(phone);
        //添加参数
        SqlParameter email = new SqlParameter("@email", SqlDbType.VarChar, 30);
        email.Value = stremail;
        myCmd.Parameters.Add(email);
        SqlParameter ReturnValue = myCmd.Parameters.Add("ReturnValue", SqlDbType.Int, 4);
        ReturnValue.Direction = ParameterDirection.ReturnValue;
        dbObj.ExecNonQuery(myCmd);
        return Convert.ToInt32(ReturnValue.Value.ToString());
    }
    public int AddTeacher(string strName, string strPassword, bool blSex, string strquestion, string stranswer, string strcardNo, string strphone, string stremail)
    {
        SqlCommand myCmd = dbObj.GetCommandProc("proc_addteacher");

        //添加参数
        SqlParameter name = new SqlParameter("@Name", SqlDbType.VarChar, 20);
        name.Value = strName;
        myCmd.Parameters.Add(name);

        //添加参数
        SqlParameter password = new SqlParameter("@Password", SqlDbType.VarChar, 20);
        password.Value = strPassword;
        myCmd.Parameters.Add(password);

        //添加参数
        SqlParameter sex = new SqlParameter("@Sex", SqlDbType.Bit, 1);
        sex.Value = blSex;
        myCmd.Parameters.Add(sex);

        //添加参数
        SqlParameter question = new SqlParameter("@question", SqlDbType.VarChar, 50);
        question.Value = strquestion;
        myCmd.Parameters.Add(question);

        //添加参数
        SqlParameter answer = new SqlParameter("@answer", SqlDbType.VarChar, 50);
        answer.Value = stranswer;
        myCmd.Parameters.Add(answer);

        //添加参数
        SqlParameter cardNo = new SqlParameter("@cardNo", SqlDbType.VarChar, 18);
        cardNo.Value = strcardNo;
        myCmd.Parameters.Add(cardNo);

        //添加参数
        SqlParameter phone = new SqlParameter("@phone", SqlDbType.VarChar, 11);
        phone.Value = strphone;
        myCmd.Parameters.Add(phone);

        //添加参数
        SqlParameter email = new SqlParameter("@email", SqlDbType.VarChar, 30);
        email.Value = stremail;
        myCmd.Parameters.Add(email);

        SqlParameter ReturnValue = myCmd.Parameters.Add("ReturnValue", SqlDbType.Int, 4);
        ReturnValue.Direction = ParameterDirection.ReturnValue;
        dbObj.ExecNonQuery(myCmd);
        return Convert.ToInt32(ReturnValue.Value.ToString());
    }
    /// <summary>
    /// 添加试题
    /// </summary>
    /// <param name="strtype">题型</param>
    /// <param name="strcontent">题目内容</param>
    /// <param name="strAText">选项A</param>
    /// <param name="strBText">选项B</param>
    /// <param name="strCText">选项C</param>
    /// <param name="strDText">选项D</param>
    /// <param name="stranswer">答案</param>
    /// <param name="stranaly">解析</param>
    /// <param name="strgrade">难易程度</param>
    /// <param name="strtcid">教师工号</param>
    /// <returns></returns>
    public int AddTest(string strtype, string strcontent, string strAText, string strBText, string strCText, string strDText, string stranswer, string stranaly, string strgrade, string strtcid)
    {
        SqlCommand myCmd = dbObj.GetCommandProc("proc_addtest");

        //添加参数
        SqlParameter type = new SqlParameter("@type", SqlDbType.VarChar, 10);
        type.Value = strtype;
        myCmd.Parameters.Add(type);

        //添加参数
        SqlParameter content = new SqlParameter("@content", SqlDbType.VarChar, 500);
        content.Value = strcontent;
        myCmd.Parameters.Add(content);

        //添加参数
        SqlParameter AText = new SqlParameter("@AText", SqlDbType.VarChar, 50);
        AText.Value = strAText;
        myCmd.Parameters.Add(AText);

        //添加参数
        SqlParameter BText = new SqlParameter("@BText", SqlDbType.VarChar, 50);
        BText.Value = strBText;
        myCmd.Parameters.Add(BText);

        //添加参数
        SqlParameter CText = new SqlParameter("@CText", SqlDbType.VarChar, 50);
        CText.Value = strCText;
        myCmd.Parameters.Add(CText);

        //添加参数
        SqlParameter DText = new SqlParameter("@DText", SqlDbType.VarChar, 50);
        DText.Value = strDText;
        myCmd.Parameters.Add(DText);

        //添加参数
        SqlParameter answer = new SqlParameter("@answer", SqlDbType.VarChar, 8);
        answer.Value = stranswer;
        myCmd.Parameters.Add(answer);

        //添加参数
        SqlParameter analy = new SqlParameter("@analy", SqlDbType.VarChar, 500);
        analy.Value = stranaly;
        myCmd.Parameters.Add(analy);

        //添加参数
        SqlParameter grade = new SqlParameter("@grade", SqlDbType.Char, 2);
        grade.Value = strgrade;
        myCmd.Parameters.Add(grade);

        //添加参数
        SqlParameter tcid = new SqlParameter("@tcid", SqlDbType.Int, 8);
        tcid.Value = strtcid;
        myCmd.Parameters.Add(tcid);

        SqlParameter ReturnValue = myCmd.Parameters.Add("ReturnValue", SqlDbType.Int, 4);
        ReturnValue.Direction = ParameterDirection.ReturnValue;
        dbObj.ExecNonQuery(myCmd);
        return Convert.ToInt32(ReturnValue.Value.ToString());
    }
    public int AddTestPaper(string strname, string streach, string strsum, string strqualified, string strstartTime, string strendTime,string strtcid,string strsumtest)
    {
        SqlCommand myCmd = dbObj.GetCommandProc("proc_addtestpaper");
        //添加参数
        SqlParameter name = new SqlParameter("@name", SqlDbType.VarChar, 20);
        name.Value = strname;
        myCmd.Parameters.Add(name);
        //添加参数
        SqlParameter each = new SqlParameter("@each", SqlDbType.Int);
        each.Value = streach;
        myCmd.Parameters.Add(each);
        //添加参数
        SqlParameter sum = new SqlParameter("@sum", SqlDbType.Int);
        sum.Value = strsum;
        myCmd.Parameters.Add(sum);
        //添加参数
        SqlParameter qualified = new SqlParameter("@qualified", SqlDbType.Int);
        qualified.Value = strqualified;
        myCmd.Parameters.Add(qualified);
        //添加参数
        SqlParameter startTime = new SqlParameter("@startTime", SqlDbType.VarChar, 30);
        startTime.Value = strstartTime;
        myCmd.Parameters.Add(startTime);
        //添加参数
        SqlParameter endTime = new SqlParameter("@endTime", SqlDbType.VarChar, 30);
        endTime.Value = strendTime;
        myCmd.Parameters.Add(endTime);
        //添加参数
        SqlParameter tcid = new SqlParameter("@tcid", SqlDbType.Int);
        tcid.Value = strtcid;
        myCmd.Parameters.Add(tcid);
        SqlParameter sumtest = new SqlParameter("@sumtest", SqlDbType.Int);
        sumtest.Value = strsumtest;
        myCmd.Parameters.Add(sumtest);

        SqlParameter ReturnValue = myCmd.Parameters.Add("ReturnValue", SqlDbType.Int, 4);
        ReturnValue.Direction = ParameterDirection.ReturnValue;
        dbObj.ExecNonQuery(myCmd);
        return Convert.ToInt32(ReturnValue.Value.ToString());
    }
    
    //***************************************选择考题界面************************************************************
    public int AddTestPaperDetail(int strtpid, int strtbid)
    {
        SqlCommand myCmd = dbObj.GetCommandProc("proc_addtestpaperdetail");

        //添加参数
        SqlParameter tpid = new SqlParameter("@tpid", SqlDbType.Int);
        tpid.Value = strtpid;
        myCmd.Parameters.Add(tpid);

        //添加参数
        SqlParameter tbid = new SqlParameter("@tbid", SqlDbType.Int);
        tbid.Value = strtbid;
        myCmd.Parameters.Add(tbid);

        SqlParameter ReturnValue = myCmd.Parameters.Add("ReturnValue", SqlDbType.Int, 4);
        ReturnValue.Direction = ParameterDirection.ReturnValue;
        dbObj.ExecNonQuery(myCmd);
        return Convert.ToInt32(ReturnValue.Value.ToString());
    }
    public int gettestpaper(string strName)
    {
        SqlCommand myCmd = dbObj.GetCommandStr("select * from testPaper where Tp_name=@Name;");
        //添加参数(用户名)
        SqlParameter Name = new SqlParameter("@Name", SqlDbType.VarChar, 50);
        Name.Value = strName;
        myCmd.Parameters.Add(Name);
        dbObj.ExecNonQuery(myCmd);
        DataTable dsTable = dbObj.GetDataSet(myCmd, "Manager");
        if (dsTable.Rows.Count > 1)
        {
            return 1;
        }
        else if(dsTable.Rows.Count==0){
            return 0;
        }
        else
        {
            return Convert.ToInt32(dsTable.Rows[0][0].ToString());
        }
        
    }
    /// <summary>
    /// 随机抽取试题，返回一个数组
    /// </summary>
    /// <param name="stringsql">随机抽题字符串</param>
    /// <param name="sumnum">抽取试题总数</param>
    /// <returns>题号数组</returns>
    public int[] randompaper(string stringsql,int sumnum)
    {
        int[] stringid = new int[sumnum];
        int n=0;
        SqlCommand myCmd = dbObj.GetCommandStr(stringsql);
        SqlDataReader readtable = myCmd.ExecuteReader();
        while (readtable.Read())
        {
            if (n < sumnum)
            {
                stringid[n] = Convert.ToInt32(readtable[0].ToString());
                n++;
            }
        }
        return stringid;
    }
    /// <summary>
    /// 把考生答题答案插入到考试明细表
    /// </summary>
    /// <param name="stranswer">考生答案</param>
    /// <param name="strtbId">试题编号</param>
    /// <param name="strtpName">试卷名</param>
    /// <returns>插入成功标识</returns>
    public int insertanswer(string stranswer,int strtbId,string strtpName){
        SqlCommand myCmd = dbObj.GetCommandProc("proc_updatepaperdetail");
        //添加参数
        SqlParameter answer = new SqlParameter("@answer", SqlDbType.VarChar, 8);
        answer.Value = stranswer;
        myCmd.Parameters.Add(answer);
        //添加参数
        SqlParameter tbid = new SqlParameter("@tbid", SqlDbType.Int);
        tbid.Value = strtbId;
        myCmd.Parameters.Add(tbid);
        //添加参数
        SqlParameter tpName = new SqlParameter("@tpName", SqlDbType.VarChar, 20);
        tpName.Value = strtpName;
        myCmd.Parameters.Add(tpName);

        SqlParameter ReturnValue = myCmd.Parameters.Add("ReturnValue", SqlDbType.Int, 4);
        ReturnValue.Direction = ParameterDirection.ReturnValue;
        dbObj.ExecNonQuery(myCmd);
        return Convert.ToInt32(ReturnValue.Value.ToString());
    }
    /// <summary>
    /// 获取试题的正确答案
    /// </summary>
    /// <param name="strtbId">试题编号</param>
    /// <returns>正确答案</returns>
    public DataTable getrightanswer(int strtbId)    
    {
        SqlCommand myCmd = dbObj.GetCommandStr("select Tb_answer from testBase where Tb_id=@tbid;");
        SqlParameter tbid = new SqlParameter("@tbid", SqlDbType.Int);
        tbid.Value = strtbId;
        myCmd.Parameters.Add(tbid);
        dbObj.ExecNonQuery(myCmd);
        DataTable dsTable = dbObj.GetDataSet(myCmd, "rightanswer");
        return dsTable;
    }
    public DataTable getpass(string strtpname)
    {
        SqlCommand myCmd = dbObj.GetCommandStr("select [Tp_qualifiedScore],[Tp_singleScore] from testPaper where Tp_name=@tpname;");
        SqlParameter tpname = new SqlParameter("@tpname", SqlDbType.VarChar, 20);
        tpname.Value = strtpname;
        myCmd.Parameters.Add(tpname);
        dbObj.ExecNonQuery(myCmd);
        DataTable dsTable = dbObj.GetDataSet(myCmd, "pass");
        return dsTable;
    }
    public int insertscore(int strstId, string strtpName, int strscore, bool strpassbit)
    {
        SqlCommand myCmd = dbObj.GetCommandProc("proc_insertscore");
        //添加参数
        SqlParameter stId = new SqlParameter("@stId", SqlDbType.Int);
        stId.Value = strstId;
        myCmd.Parameters.Add(stId);
        //添加参数
        SqlParameter tpName = new SqlParameter("@tpName", SqlDbType.VarChar, 20);
        tpName.Value = strtpName;
        myCmd.Parameters.Add(tpName);
        //添加参数
        SqlParameter score = new SqlParameter("@score", SqlDbType.Int);
        score.Value = strscore;
        myCmd.Parameters.Add(score);
        //添加参数
        SqlParameter passbit = new SqlParameter("@passbit", SqlDbType.Int);
        passbit.Value = strpassbit;
        myCmd.Parameters.Add(passbit);
        SqlParameter ReturnValue = myCmd.Parameters.Add("ReturnValue", SqlDbType.Int, 4);
        ReturnValue.Direction = ParameterDirection.ReturnValue;
        dbObj.ExecNonQuery(myCmd);
        return Convert.ToInt32(ReturnValue.Value.ToString());
        //        USE [administrator]
        //GO
        ///****** Object:  StoredProcedure [dbo].[proc_addtestpaperdetail]    Script Date: 2018/5/10 11:08:32 ******/
        //SET ANSI_NULLS ON
        //GO
        //SET QUOTED_IDENTIFIER ON
        //GO
        //create PROCEDURE [dbo].[proc_insertscore]

        //    @stId int,
        //    @tpName varchar(20),
        //    @score int,
        //    @passbit int
	
        //AS
	
        //BEGIN
        //    Insert  score(St_id,Tp_id,score,status)
        //        values(@stId,@tpName,@score,@passbit)
        //        select Tp_id form testPaper where Tp_name=@tpName
        //    return 1;
        //END
    }
    //***************************************修改界面************************************************************
    /// <summary>
    /// 通过用户ID，获取用户的详细信息
    /// </summary>
    /// <param name="IntMemberID">用户ID代号</param>
    /// <returns>返回数据集的表的集合</returns>
    public DataTable GetUserInfo(int IntMemberID)
    {
        SqlCommand myCmd = dbObj.GetCommandProc("proc_GetUI");
        //添加参数
        SqlParameter memberId = new SqlParameter("@MemberID", SqlDbType.Int, 4);
        memberId.Value = IntMemberID;
        myCmd.Parameters.Add(memberId);
        dbObj.ExecNonQuery(myCmd);
        DataTable dsTable = dbObj.GetDataSet(myCmd, "tbUser");
        return dsTable;
    }
    /// <summary>
    /// 修改用户表的信息
    /// </summary>
    /// <param name="strName">会员名</param>
    /// <param name="strPassword">密码</param>
    /// <param name="strRealName">真实姓名</param>
    /// <param name="blSex">性别</param>
    /// <param name="strPhonecode">电话号码</param>
    /// <param name="strEmail">E_Mail</param>
    /// <param name="strAddress">会员详细地址</param>
    /// <param name="strPostCode">邮编</param>
    /// <param name="IntMemberID">用户的ID代号</param>
    public void MedifyUser(string strName, string strPassword, string strRealName, bool blSex, string strPhonecode, string strEmail, string strAddress, string strPostCode, int IntMemberID)
    {
        SqlCommand myCmd = dbObj.GetCommandProc("proc_ModifyUser");
        //添加参数
        SqlParameter name = new SqlParameter("@UserName", SqlDbType.VarChar, 50);
        name.Value = strName;
        myCmd.Parameters.Add(name);
        //添加参数
        SqlParameter password = new SqlParameter("@Password", SqlDbType.VarChar, 50);
        password.Value = strPassword;
        myCmd.Parameters.Add(password);
        //添加参数
        SqlParameter realName = new SqlParameter("@RealName", SqlDbType.VarChar, 50);
        realName.Value = strRealName;
        myCmd.Parameters.Add(realName);
        //添加参数
        SqlParameter sex = new SqlParameter("@Sex", SqlDbType.Bit, 1);
        sex.Value = blSex;
        myCmd.Parameters.Add(sex);
        //添加参数
        SqlParameter phonecode = new SqlParameter("@Phonecode", SqlDbType.VarChar, 20);
        phonecode.Value = strPhonecode;
        myCmd.Parameters.Add(phonecode);
        //添加参数
        SqlParameter email = new SqlParameter("@Email", SqlDbType.VarChar, 50);
        email.Value = strEmail;
        myCmd.Parameters.Add(email);
        //添加参数
        SqlParameter address = new SqlParameter("@Address", SqlDbType.VarChar, 200);
        address.Value = strAddress;
        myCmd.Parameters.Add(address);
        //添加参数
        SqlParameter postCode = new SqlParameter("@PostCode", SqlDbType.Char, 10);
        postCode.Value = strPostCode;
        myCmd.Parameters.Add(postCode);
        //添加参数
        SqlParameter memberId = new SqlParameter("@MemberId", SqlDbType.Int, 4);
        memberId.Value = IntMemberID;
        myCmd.Parameters.Add(memberId);
        dbObj.ExecNonQuery(myCmd);
    }

}