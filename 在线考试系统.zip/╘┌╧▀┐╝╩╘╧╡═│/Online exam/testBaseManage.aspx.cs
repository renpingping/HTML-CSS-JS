﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;

public partial class testBaseManage : System.Web.UI.Page
{
    DBClass dbObj = new DBClass();
    CommonClass ccObj = new CommonClass();
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }

    protected void GridView2_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        //如果是绑定数据行 
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            if (e.Row.RowState == DataControlRowState.Normal || e.Row.RowState == DataControlRowState.Alternate)
            {
                int pid = Convert.ToInt32(e.Row.Cells[1].Text.Trim());
                SqlCommand myCmd = dbObj.GetCommandStr("select Tb_id from testPaperDetail where Tb_id=@Tbid;");
                SqlParameter id = new SqlParameter("@Tbid", SqlDbType.Int);
                id.Value = pid;
                myCmd.Parameters.Add(id);
                dbObj.ExecNonQuery(myCmd);
                DataTable dsTable = dbObj.GetDataSet(myCmd, "Manager");
                int n = Convert.ToInt32(dsTable.ToString());
                if (n == 1)
                {
                    ((LinkButton)e.Row.Cells[8].Controls[0]).Attributes.Add("onclick", "javascript:return alert('此题已用于试卷中，不能删除！')");
                }
                else
                {
                    ((LinkButton)e.Row.Cells[8].Controls[0]).Attributes.Add("onclick", "javascript:return confirm('你确认要删除题目：\"" + e.Row.Cells[1].Text + "\"吗?')");
                }
            }
        } 
    }
}