﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class addexam : System.Web.UI.Page
{
    CommonClass ccObj = new CommonClass();
    UserClass ucObj = new UserClass();
    DBClass dbObj = new DBClass();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void addLinkButton_Click(object sender, EventArgs e)
    {
        int tpId = ucObj.gettestpaper(nameTextBox.Text.Trim());
        if (tpId == 1||(tpId>1))
        {
            Response.Write(ccObj.MessageBoxPage("试卷名重复，请修改"));
        }
        else
        {
            int IntReturnValue = ucObj.AddTestPaper(nameTextBox.Text.Trim(), eachTextBox.Text.Trim(), sumTextBox.Text.Trim(), qualifiedTextBox.Text.Trim(), startTime.Text.Trim(), endTime.Text.Trim(), tcidTextBox.Text.Trim(), sumtestTextBox.Text.Trim());

            if (IntReturnValue == 1)
            {
                Response.Write(ccObj.MessageBoxPage("添加成功！"));
                Response.Write("<script>function chosetest(){var chosetest = document.getElementById(\"choseQuestions\"); chosetest.display = \"block\";}</script>");
            }
            else
            {
                Response.Write(ccObj.MessageBoxPage("添加失败！"));
            }
        }
        
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        string name;
        name = nameTextBox.Text.Trim();
        bool atLeastOneRowSelected = false;
        int testId;
        int count = 0;
        foreach (GridViewRow i in testbase.Rows)
        {
            CheckBox cb = (CheckBox)i.FindControl("selector");
            if (cb.Checked)
            {
                atLeastOneRowSelected = true;
                testId = Convert.ToInt32(testbase.DataKeys[i.RowIndex].Value);
                int tpId = ucObj.gettestpaper(name);
                //Response.Write(ccObj.MessageBoxPage(name+"试卷Id："+tpId));
                int IntReturnValue = ucObj.AddTestPaperDetail(tpId, testId);
                if (IntReturnValue == 1)
                {
                    count += 1;
                }
            } 
        }
        Label8.Text = "选择题目总数："+count.ToString();
        
    }
    
    //   重置
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        nameTextBox.Text = "";
        eachTextBox.Text = "";
        sumTextBox.Text = "";
        qualifiedTextBox.Text = "";
        startTime.Text = "";
        endTime.Text = "";
        tcidTextBox.Text = "";
        sumtestTextBox.Text = "";
    }
    //随机组卷
    protected void Button2_Click(object sender, EventArgs e)
    {
        string name;
        name = nameTextBox.Text.Trim();       //试卷名
        int sumnum = Convert.ToInt32(sumtestTextBox.Text.Trim().ToString()); //试卷题目总数
        int tpId = ucObj.gettestpaper(name);  //试卷ID
        string sqlstring = "select top " + sumnum + " Tb_id from testBase order by newid();";
        int[] stringid = new int[sumnum];
        stringid = ucObj.randompaper(sqlstring, sumnum);
        int IntReturnValue;
         for (int x = 0; x < stringid.Length; x++)  //用于循环输入题号
         {
             //Label8.Text += " 、 "+stringid[x].ToString();
             IntReturnValue = ucObj.AddTestPaperDetail(tpId, stringid[x]);
         }
    }
}