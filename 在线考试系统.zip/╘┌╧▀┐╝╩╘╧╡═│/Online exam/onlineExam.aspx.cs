﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
public partial class onlineExam : System.Web.UI.Page
{
    CommonClass ccObj = new CommonClass();
    UserClass ucObj = new UserClass();
    string tpName;
    int stId;
    protected void Page_Load(object sender, EventArgs e)
    {
        tpname.Text = Session["St_name"].ToString();           //学生名
        tpName = Request["testname"];                          //试卷名
        stId = Convert.ToInt32(Session["St_id"].ToString());   //学号
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        System.Web.UI.WebControls.RadioButtonList radioList;
        System.Web.UI.WebControls.Label lab;
        string studentanswer = "";
        int tbId = 0;
        string rightanswer,pass;
        int score=0;
        bool passbit;
        DataTable dsTable2 = ucObj.getpass(tpName);
        foreach (DataListItem dl in DataList1.Items)//对单选题每题进行判断用户选择答案
        {
            radioList = (System.Web.UI.WebControls.RadioButtonList)dl.FindControl("RadioButtonList1");
            studentanswer = radioList.SelectedItem.Value;                        // 考生选择的答案
            
            lab = (Label)dl.FindControl("Label1");
            tbId = Convert.ToInt32(lab.Text);                                    // 试题编号
            //Response.Write(ccObj.MessageBoxPage("试题编号：" + tbId +"，试卷名："+ tpName));
            int returnNum = ucObj.insertanswer(studentanswer, tbId, tpName);     //调用sql语句插入试卷明细表
            
            DataTable dsTable = ucObj.getrightanswer(tbId);
            rightanswer = dsTable.Rows[0][0].ToString();                          // 正确答案
            //Response.Write(ccObj.MessageBoxPage("答案：" + studentanswer+"；正确答案："+rightanswer));
            if (rightanswer == studentanswer)
            {
                score = score + Convert.ToInt32(dsTable2.Rows[0][1].ToString());
            }
        }
        if (Convert.ToInt32(dsTable2.Rows[0][0].ToString()) > score)
        {
            pass = "不合格";
            passbit = false;
        }
        else
        {
            pass = "合格";
            passbit = true;
        }                  
        Response.Write(ccObj.MessageBoxPage("成绩：" + score + "，" + pass));
        int returnscoreid = ucObj.insertscore(stId, tpName, score, passbit);
    }
}